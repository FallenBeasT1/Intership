#include "SubscriptionManager.h"
#include "fstream"
void SubscriptionManager::addSubscriber()
{
	if (subscribersCount == MAX_SUBSCRIBERS)
		return;
	subscribers[subscribersCount] = Subscriber::getRandomSubscriber();
	subscribersCount = subscribersCount + 1;
}
void SubscriptionManager::addMultipleSubscribers(int N)
{
	for (int i = 0; i < N; i = i + 1)
	{
		addSubscriber();
	}
}
void SubscriptionManager::printSubscribersWithtwoYearContract()
{
	cout << Subscriber::getHeader();
	for (int i = 0; i < subscribersCount; i = i + 1)
	{
		if (subscribers[i].getContractterm() == 2)
		{
			cout << '\n';
			subscribers[i].print();
		}
	}
}
void SubscriptionManager::printSubscribersHavingMinimumFee(float fee)
{
	cout << Subscriber::getHeader();
	for (int i = 0; i < subscribersCount; i = i + 1)
	{
		if (subscribers[i].getFee() >= fee)
		{
			cout << '\n';
			subscribers[i].print();
		}
	}
}
void SubscriptionManager::generateListOfCallsForEachSubscriber()
{
	for (int i = 0; i < subscribersCount; i = i + 1)
	{
		subscribers[i].generateListOfCalls();
	}
}
void SubscriptionManager::printListOfConversations()
{
	for (int i = 0; i < subscribersCount; i = i + 1)
	{
		subscribers[i].printListOfConversations();
	}
}
void SubscriptionManager::calculateMonthlyFee()
{
	for (int i = 0; i < subscribersCount; i = i + 1)
	{
		subscribers[i].calculateMonthlyFee();
	}
}
void SubscriptionManager::listByPhoneNumber()
{
	cout << Subscriber::getHeader()<<"\n";
	for (int i = 0; i < subscribersCount; i = i + 1)
	{
		int min=i;
		for (int j = i + 1; j < subscribersCount; j = j + 1)
		{
			if (subscribers[min].getPhone() > subscribers[j].getPhone())
			{
				min = j;
			}
		}
		Subscriber temp = subscribers[min];
		subscribers[min] = subscribers[i];
		subscribers[i] = temp;
		subscribers[i].print();
		cout << '\n';
	}
}
void SubscriptionManager::listByAmount()
{
	cout << Subscriber::getHeader() << "\n";
	for (int i = 0; i < subscribersCount; i = i + 1)
	{
		int min = i;
		for (int j = i + 1; j < subscribersCount; j = j + 1)
		{
			if (subscribers[min].getFee() > subscribers[j].getFee())
			{
				min = j;
			}
		}
		Subscriber temp = subscribers[min];
		subscribers[min] = subscribers[i];
		subscribers[i] = temp;
		subscribers[i].print();
		cout << '\n';
	}
}
void SubscriptionManager::printSubscriberWithShortestConversation()
{
	cout << Subscriber::getHeader() << "\n";
	int shortInd = 0;
	for (int i = 1; i < subscribersCount; i = i + 1)
	{
		if (subscribers[i].getShortestConversation() < subscribers[shortInd].getShortestConversation())
			shortInd = i;
	}
	if(subscribersCount>0)
		subscribers[shortInd].print();
}
void SubscriptionManager::printSubscriberWithMostSpokenInternationalCalls()
{
	cout << Subscriber::getHeader() << "\n";
	int maxInd = 0;
	for (int i = 1; i < subscribersCount; i = i + 1)
	{
		if (subscribers[i].getInternationCallsCount() > subscribers[maxInd].getShortestConversation())
			maxInd = i;
	}
	if (subscribersCount > 0)
		subscribers[maxInd].print();
}
void SubscriptionManager::writeOnFile()
{
	fstream fs("Subscribers.txt", ios::out);
	fs << Subscriber::getHeader() << "\n";
	if (fs.is_open())
	{
		for (int i = 0; i < subscribersCount; i = i + 1)
		{
			fs << subscribers[i].getSubscriber()<<"\n";
		}
		fs.close();
	}
}