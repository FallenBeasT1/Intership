#include <string>
#include<iostream>
using namespace std;
#define CALLS_LIMIT 20
struct Call
{
	bool isNational;
	int duration;
	Call()
	{}
	Call(bool nation, int dur)
	{
		isNational = nation;
		duration = dur;
	}
	static Call getRandomCall()
	{
		return Call(rand() % 2 == 0 ? true : false, rand() % 3600 + 1);
	}
};
class Subscriber
{
	string contractNumber;
	int contractTerm;
	string name;
	string phone;
	Call calls[CALLS_LIMIT];
	int callsCount;
	float monthlyFee=0;
public:
	Subscriber();
	Subscriber(string contract, int term,string nm,string ph,float fee);
	static Subscriber getRandomSubscriber();
	int getContractterm();
	string getSubscriber();
	void print();
	static string getHeader();
	float getFee();
	void generateListOfCalls();
	void printListOfConversations();
	void calculateMonthlyFee();
	string getPhone();
	int getShortestConversation();
	int getInternationCallsCount();
};