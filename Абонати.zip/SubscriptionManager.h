#define MAX_SUBSCRIBERS 10
#include "Subscriber.h"
class SubscriptionManager
{
	Subscriber subscribers[MAX_SUBSCRIBERS];
	int subscribersCount=0;
public:
	void addSubscriber();
	void addMultipleSubscribers(int N);
	void printSubscribersWithtwoYearContract();
	void printSubscribersHavingMinimumFee(float fee);
	void generateListOfCallsForEachSubscriber();
	void printListOfConversations();
	void calculateMonthlyFee();
	void listByPhoneNumber();
	void listByAmount();
	void printSubscriberWithShortestConversation();
	void printSubscriberWithMostSpokenInternationalCalls();
	void writeOnFile();
};